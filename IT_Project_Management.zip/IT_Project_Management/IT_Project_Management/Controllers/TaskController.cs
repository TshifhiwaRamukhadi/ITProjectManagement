﻿using IT_Project_Management.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IT_Project_Management.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
        private readonly ITProjectManagementContext itprojectmanagementContext;
        public TaskController(ITProjectManagementContext itprojectmanagementContext)
        {
            this.itprojectmanagementContext = itprojectmanagementContext;
        }
        [HttpGet]
        [Route("GetTasks")]
        public List<task> GetTasks()
        {
            return itprojectmanagementContext.Tasks.ToList();
        }
        [HttpGet]
        [Route("GetTask")]
        public task GetTask(int id)
        {
            return itprojectmanagementContext.Tasks.Where(x => x.Id == id).FirstOrDefault();
        }
        [HttpPost]
        [Route("AddTask")]
        public string AddTask(task task)
        {
            string response = string.Empty;
            itprojectmanagementContext.Tasks.Add(task);
            itprojectmanagementContext.SaveChanges();
            return "Task successfully added";
        }
        [HttpPut]
        [Route("UpdateTask")]
        public string UpdateTask(task task)
        {
            itprojectmanagementContext.Entry(task).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            itprojectmanagementContext.SaveChanges();
            return "Task Updated successfully";
        }
        [HttpDelete]
        [Route("DeleteTask")]
        public string DeleteTask(int id)
        {
            task task = itprojectmanagementContext.Tasks.Where(x => x.Id == id).FirstOrDefault();
            if (task != null)
            {
                itprojectmanagementContext.Tasks.Remove(task);
                itprojectmanagementContext.SaveChanges();
                return "task successfully deleted";
            }
            else
            {
                return "task not found";
            }
        }
    }
}
