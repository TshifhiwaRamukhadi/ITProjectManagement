﻿using IT_Project_Management.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IT_Project_Management.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class projectController : ControllerBase
    {
        private readonly ITProjectManagementContext itprojectmanagementContext;
        public projectController(ITProjectManagementContext itprojectmanagementContext)
        {
            this.itprojectmanagementContext = itprojectmanagementContext;
        }
        [HttpGet]
        [Route("GetTasks")]
        public List<Project> GetTasks()
        {
            return itprojectmanagementContext.Projects.ToList();
        }
        [HttpGet]
        [Route("GetTasks")]
        public Project GetTask(int id)
        {
            return itprojectmanagementContext.Projects.Where(x => x.Id == id).FirstOrDefault();
        }
        [HttpPost]
        [Route("AddTask")]
        public string AddTask(Project project)
        {
            string response = string.Empty;
            itprojectmanagementContext.Projects.Add(project);
            itprojectmanagementContext.SaveChanges();
            return "Task successfully added";
        }
        [HttpPut]
        [Route("UpdateTask")]
        public string UpdateProject(Project project)
        {
            itprojectmanagementContext.Entry(project).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            itprojectmanagementContext.SaveChanges();
            return "Task Updated successfully";
        }
        [HttpDelete]
        [Route("DeleteTask")]
        public string DeleteTask(int id)
        {
            Project project = itprojectmanagementContext.Projects.Where(x => x.Id == id).FirstOrDefault();
            if (project != null)
            {
                itprojectmanagementContext.Projects.Remove(project);
                itprojectmanagementContext.SaveChanges();
                return "task successfully deleted";
            }
            else
            {
                return "task not found";
            }
        }
    }
}
