﻿using IT_Project_Management.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IT_Project_Management.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class userController : ControllerBase
    {
        private readonly ITProjectManagementContext itprojectmanagementContext;
        public userController(ITProjectManagementContext itprojectmanagementContext)
        {
            this.itprojectmanagementContext = itprojectmanagementContext;
        }

        [HttpGet]
        [Route("GetUsers")]
        public List<User> GetUsers()
        {
            return itprojectmanagementContext.Users.ToList();
        }

        [HttpGet]
        [Route("GetUser")]
        public User GetUser(int id)
        {
            return itprojectmanagementContext.Users.Where(x => x.Id == id).FirstOrDefault();
        }
        [Authorize(Roles = "Administrator")]
        [HttpPost]
        [Route("AddUsers")]
        public string AddUser(User user)
        {
            string response = string.Empty;
            itprojectmanagementContext.Users.Add(user);
            itprojectmanagementContext.SaveChanges();
            return "User successfully added";
        }
        [HttpPut]
        [Route("UpdateUser")]
        public string UpdateUser(User user)
        {
            itprojectmanagementContext.Entry(user).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            itprojectmanagementContext.SaveChanges();
            return "User update successful";
        }
        [HttpDelete]
        [Route("DeleteUser")]
        public string DeleteUser(int id)
        {
            User user = itprojectmanagementContext.Users.Where(x => x.Id == id).FirstOrDefault();
            if (user != null)
            {
                itprojectmanagementContext.Users.Remove(user);
                itprojectmanagementContext.SaveChanges();
                return "User Successfully deleted";
            }
            else
            {
                return "User not found";
            }

        }

    }
}
