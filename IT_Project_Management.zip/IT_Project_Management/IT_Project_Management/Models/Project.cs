﻿using System.ComponentModel.DataAnnotations;

namespace IT_Project_Management.Models
{
    public class Project
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [StringLength(50)]
        public string Title { get; set; }
        [Required]
        [StringLength(50)]
        public string Description { get; set; }

        public int ProjectManagerId { get; set; }

        public User ProjectManager { get; set; }

        public List<task> Tasks { get; set; } = new List<task>();
    }
}
