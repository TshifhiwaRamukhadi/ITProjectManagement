﻿using Microsoft.EntityFrameworkCore;

namespace IT_Project_Management.Models
{
    public class ITProjectManagementContext : DbContext
    {
        public ITProjectManagementContext(DbContextOptions<ITProjectManagementContext> options): base(options)
        {


        }
        public DbSet<User> Users { get; set; }
        public DbSet<Project> Projects { get; set; }
        public DbSet<task> Tasks { get; set; }

    }
}
