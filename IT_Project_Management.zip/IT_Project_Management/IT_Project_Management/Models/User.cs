﻿using System.ComponentModel.DataAnnotations;

namespace IT_Project_Management.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        [Required]
        [StringLength(50)]
        public string Surname { get; set; }
        [Required]
        [StringLength(50)]
        public string JobTitle { get; set; }
        public string Role { get; set; }
        public ICollection<task> Tasks { get; set; }
        public string PasswordHash { get; set; }  // for storing hashed passwords
    }
}
