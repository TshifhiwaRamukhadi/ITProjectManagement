﻿using System.ComponentModel.DataAnnotations;

namespace IT_Project_Management.Models
{
    public class task
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [StringLength(50)]
        public string Title { get; set; }
        [Required]
        [StringLength(50)]
        public string Description { get; set; }
        [Required]
        [StringLength(50)]
        public string Status { get; set; } // "To Start", "In Progress", "Complete"
        public int AssignedToUserId { get; set; }
        public User AssignedToUser { get; set; }
        public int ProjectId { get; set; }
        public Project Project { get; set; }

        [Required]
        public DateTime AssignedTime { get; set; }

        public DateTime? CompletionTime { get; set; }
    }
}
